import WeatherCard from './WeatherCard'

export default WeatherCard
