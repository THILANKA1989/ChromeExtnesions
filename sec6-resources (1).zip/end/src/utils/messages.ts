export enum Messages {
  TOGGLE_OVERLAY,
}
