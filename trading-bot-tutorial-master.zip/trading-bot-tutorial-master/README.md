# Tutorial: Building a Simple Crypto Trading Bot on Chrome Extension
This is a step by step guide that will show you how to build a real crypto trading bot. After completing this tutorial you will also learn how you can use Chrome Extension to automate certain tasks on websites.

Please see the guide here: https://medium.com/javascript-in-plain-english/chrome-extension-building-a-simple-crypto-trading-bot-8126ebd4fbf9
